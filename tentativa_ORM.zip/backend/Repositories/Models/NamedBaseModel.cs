namespace Resenhapp;

public class NamedBase: Base
{
    public string Name { get; set; } = string.Empty;
}
