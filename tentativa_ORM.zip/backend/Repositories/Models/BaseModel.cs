namespace Resenhapp;

public class Base 
{
    public int Id { get; set; }
}

