namespace Resenhapp;

public interface IImageWebScraper
{
    string getProfileImageLink(string intagram);
}