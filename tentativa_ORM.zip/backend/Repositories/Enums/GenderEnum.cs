namespace Resenhapp
{
    public enum Gender
    {
        Male, Female, NonBI

    }
}