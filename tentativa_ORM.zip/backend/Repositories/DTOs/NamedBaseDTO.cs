namespace Resenhapp;

public class NamedBaseDTO: BaseDTO
{
    public string Name { get; set; } = string.Empty;
}
