namespace Resenhapp;

public class BaseDTO
{
    public int Id { get; set; }
}

