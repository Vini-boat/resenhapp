
namespace Resenhapp;

using Microsoft.EntityFrameworkCore;
using Resenhapp.Data;
using SQLitePCL;

public class ItemService : IItemService
{
    private readonly DataContext _context;
    public ItemService(DataContext context)
    {
        _context = context;
    }

    public async Task Create(Item item)
    {
        _context.Items.Add(item);
        await _context.SaveChangesAsync();
    }

    public async Task Delete(Item item)
    {
        _context.Items.Remove(item);
        await _context.SaveChangesAsync();
    }

    public async Task<List<Item>> GetAll()
    {
        return await _context.Items.ToListAsync();
    }

    public async Task<Item?> GetById(int id)
    {
        return await _context.Items.FindAsync(id);
    }
}