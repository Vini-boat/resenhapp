using AutoMapper;
using Microsoft.AspNetCore.Mvc;

namespace Resenhapp.Controllers;

[ApiController]
public class ItemController: ControllerBase
{
    private readonly IItemService _dbservice;
    private readonly IMapper _mapper;
    public ItemController(IItemService service, IMapper mapper)
    {
        _dbservice = service;
        _mapper = mapper;
    }

    [HttpGet("[controller]")]
    public async Task<ActionResult<List<ItemDTO>>> GetAll()
    {
        var items = await _dbservice.GetAll();
        return Ok(_mapper.Map<List<Item>>(items));
    }
    
    [HttpGet("[controller]/{id}")]
    public IActionResult GetById([FromRoute] int id)
    {
        var item = _dbservice.GetById(id);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpPost("[controller]")]
    public async Task<IActionResult> Add([FromBody]ItemDTO new_item)
    {
        var item = _mapper.Map<Item>(new_item);
        await _dbservice.Create(item);
        return Ok(_dbservice.GetAll());
    }

    [HttpDelete("[controller]/{id}")]
    public async Task<IActionResult> DeleteById([FromRoute]int id)
    {
        var item = await _dbservice.GetById(id);
        if (item == null) return NotFound();
        await _dbservice.Delete(item);
        return Ok(_dbservice.GetAll());
    }

    [HttpPut("[controller]")]
    public async Task<IActionResult> Update([FromBody]Item updated_item)
    {
        var item = await _dbservice.GetById(updated_item.Id);
        if (item == null) return NotFound();
        return NotFound("Ainda n implementado");
        // return Ok(); 
    }
}
