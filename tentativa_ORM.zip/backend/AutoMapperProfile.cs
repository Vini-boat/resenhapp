using AutoMapper;

namespace Resenhapp;

public class AutoMapperProfile: Profile
{
    public AutoMapperProfile()
    {
        CreateMap<Guest, GuestDTO>();
        CreateMap<GuestDTO, Guest>();

        CreateMap<Item, ItemDTO>();
        CreateMap<ItemDTO, Item>();
        
        CreateMap<Person, PersonDTO>();
        CreateMap<PersonDTO, Person>();
    }
}